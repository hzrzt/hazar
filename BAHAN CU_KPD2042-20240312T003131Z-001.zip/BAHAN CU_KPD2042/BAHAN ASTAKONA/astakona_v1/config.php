<?php
//DATABASE CONNECTION
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "astakona2";
$conn=mysqli_connect($servername, $username, $password, $dbname);
?>
