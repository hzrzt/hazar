<?php
//DATABASE CONNECTION
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydb5";
$conn=mysqli_connect($servername, $username, $password, $dbname);
?>
